<?php
//USE ;end TO SEPARATE SQL STATEMENTS. DON'T USE ;end IN ANY OTHER PLACES!

$sql = [];
$count = 0;

//v0.0.00
$sql[$count][0] = "0.0.00";
$sql[$count][1] = "-- First version, nothing to update";


//v0.0.0x
$count++;
$sql[$count][0] = "0.0.0x";
$sql[$count][1] = "-- One block for each subsequent version, place sql statements here for version, seperated by ;end";
